<div class="page sign">
    <div class="row">
        <div class="col-sm-4 col-sm-offset-4 form-box">
            <div class="form-top text-center">
                <h3>Checking robots.txt</h3>
            </div><!-- form-top -->
            <div class="form-bottom contact-form">
                <form role="form" action="" method="post">
                    <div class="form-group">
                        <label class="sr-only" for="site">URL</label>
                        <input type="text" name="url" placeholder="URL..." class="form-control" required>
                    </div><!-- form-group -->
                    <div class="text-center">
                        <button type="submit" name="robots" class="btn btn-success" value="submit">Check ...</button>
                    </div>
                </form>
            </div><!-- form-bottom contact-form -->
        </div><!-- col-sm-4 col-sm-offset-4 form-box -->
    </div><!-- row -->
</div> <!-- sign-page  -->