

</div> <!--container-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../../../vendor/components/jquery/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="../../../vendor/components/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>