<div class="row">
    <div class="col-md-12 text-center">
        <h1>404</h1>
        <h3>Page not found.</h3>
        <a href="/">Go to Home...</a>
    </div>
</div>